import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Phone, 
  MapPin, 
  Calendar, 
  Clock, 
  Menu, 
  X, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  Trash2, 
  ExternalLink, 
  Star, 
  Heart, 
  Instagram, 
  Award, 
  ShieldCheck, 
  Users, 
  MessageSquare, 
  Plus, 
  Bookmark,
  Send
} from 'lucide-react';

import { Service, Appointment, Review } from './types';
import { SERVICES, CATEGORIES, TESTIMONIALS, BUSINESS_INFO, FAQS } from './data';
// @ts-expect-error - static image import handled by Vite
import heroImg from './assets/images/beauty_salon_hero_1783864623618.jpg';

export default function App() {
  // Navigation states
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Service category tab state
  const [activeCategory, setActiveCategory] = useState('todos');

  // Booking Form State
  const [formData, setFormData] = useState({
    clientName: '',
    clientPhone: '',
    serviceId: SERVICES[0].id,
    date: '',
    time: '09:00',
    notes: ''
  });

  // Turnos (Bookings) persistent state
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  
  // Custom Reviews persistent state
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newReview, setNewReview] = useState({
    author: '',
    rating: 5,
    text: ''
  });
  const [isAddingReview, setIsAddingReview] = useState(false);
  const [reviewSuccess, setReviewSuccess] = useState(false);

  // FAQ open indexes
  const [openFaqIndexes, setOpenFaqIndexes] = useState<number[]>([0]);

  // Selected appointment for confirmation modal
  const [activeConfirmationAppointment, setActiveConfirmationAppointment] = useState<Appointment | null>(null);

  // Ref for auto-scroll
  const formRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLElement>(null);
  const reviewFormRef = useRef<HTMLFormElement>(null);

  // Load from local storage
  useEffect(() => {
    const savedAppointments = localStorage.getItem('aura_appointments');
    if (savedAppointments) {
      try {
        setAppointments(JSON.parse(savedAppointments));
      } catch (e) {
        console.error('Error parsing appointments', e);
      }
    }

    const savedReviews = localStorage.getItem('aura_custom_reviews');
    if (savedReviews) {
      try {
        setReviews(JSON.parse(savedReviews));
      } catch (e) {
        console.error('Error parsing custom reviews', e);
      }
    }
  }, []);

  // Save appointments helper
  const saveAppointments = (updated: Appointment[]) => {
    setAppointments(updated);
    localStorage.setItem('aura_appointments', JSON.stringify(updated));
  };

  // Save reviews helper
  const saveReviews = (updated: Review[]) => {
    setReviews(updated);
    localStorage.setItem('aura_custom_reviews', JSON.stringify(updated));
  };

  // Pre-fill service and scroll to form
  const handleSelectAndScrollToBook = (serviceId: string) => {
    setFormData(prev => ({ ...prev, serviceId }));
    
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  // Handle Form Submission
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientName.trim() || !formData.clientPhone.trim() || !formData.date || !formData.time) {
      alert('Por favor complete todos los campos obligatorios.');
      return;
    }

    const selectedService = SERVICES.find(s => s.id === formData.serviceId) || SERVICES[0];

    const newAppointment: Appointment = {
      id: 'apt_' + Date.now(),
      clientName: formData.clientName,
      clientPhone: formData.clientPhone,
      serviceId: selectedService.id,
      serviceName: selectedService.name,
      price: selectedService.price,
      date: formatDateDisplay(formData.date),
      time: formData.time,
      notes: formData.notes,
      createdAt: new Date().toLocaleDateString('es-AR'),
      status: 'pending_whatsapp'
    };

    const updated = [newAppointment, ...appointments];
    saveAppointments(updated);
    setActiveConfirmationAppointment(newAppointment);

    // Reset some form parts
    setFormData(prev => ({
      ...prev,
      notes: ''
    }));
  };

  // Handle Review Submission
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.author.trim() || !newReview.text.trim()) {
      alert('Por favor completa tu nombre y comentario.');
      return;
    }

    const createdReview: Review = {
      id: 'rev_' + Date.now(),
      author: newReview.author,
      rating: newReview.rating,
      text: newReview.text,
      date: 'Reciente'
    };

    const updated = [createdReview, ...reviews];
    saveReviews(updated);
    
    // Reset review form
    setNewReview({ author: '', rating: 5, text: '' });
    setIsAddingReview(false);
    setReviewSuccess(true);
    setTimeout(() => setReviewSuccess(false), 4000);
  };

  // Delete appointment
  const handleDeleteAppointment = (id: string) => {
    if (window.confirm('¿Deseas cancelar el registro de este turno de tu historial local?')) {
      const updated = appointments.filter(a => a.id !== id);
      saveAppointments(updated);
    }
  };

  // Format date display (yyyy-mm-dd -> dd/mm/yyyy)
  const formatDateDisplay = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateStr;
  };

  // Construct whatsapp message url
  const getWhatsAppBookingUrl = (apt: Appointment) => {
    const text = `¡Hola Aura Estética! 🌸 Me comunico desde la web para confirmar mi reserva de turno:\n\n` +
      `*Servicio:* ${apt.serviceName}\n` +
      `*Cliente:* ${apt.clientName}\n` +
      `*Teléfono:* ${apt.clientPhone}\n` +
      `*Fecha:* ${apt.date}\n` +
      `*Hora:* ${apt.time} hs\n` +
      (apt.notes ? `*Notas:* ${apt.notes}\n` : '') +
      `*Precio:* $${apt.price.toLocaleString('es-AR')}\n\n` +
      `Quedo a la espera de su confirmación. ¡Muchas gracias! ✨`;
    return `https://wa.me/5491121571015?text=${encodeURIComponent(text)}`;
  };

  // Toggle FAQ Accordion
  const toggleFaq = (index: number) => {
    if (openFaqIndexes.includes(index)) {
      setOpenFaqIndexes(openFaqIndexes.filter(i => i !== index));
    } else {
      setOpenFaqIndexes([...openFaqIndexes, index]);
    }
  };

  // Filtered services list
  const filteredServices = activeCategory === 'todos' 
    ? SERVICES 
    : SERVICES.filter(s => s.category === activeCategory);

  // Combine default reviews and custom local reviews
  const allReviews = [...reviews, ...TESTIMONIALS];

  // Get current date in YYYY-MM-DD format for date picker min property
  const getTodayDateString = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8] text-neutral-800 font-sans selection:bg-pink-100 selection:text-pink-900 overflow-x-hidden">
      
      {/* HEADER / NAVIGATION BAR */}
      <header className="sticky top-0 z-40 bg-white/70 backdrop-blur-md border-b border-pink-100 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            
            {/* Logo */}
            <a href="#" className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                <span className="text-white font-bold text-xl font-sans">A</span>
              </div>
              <div>
                <span className="font-sans text-xl sm:text-2xl font-light tracking-widest text-pink-600 uppercase block leading-none">
                  AURA <span className="font-semibold">ESTÉTICA</span>
                </span>
                <span className="text-[10px] tracking-widest uppercase text-pink-400 font-semibold block mt-1">
                  & Bienestar
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center gap-8 font-medium text-sm text-neutral-600">
              <a href="#" className="hover:text-pink-500 transition-colors">Inicio</a>
              <a href="#servicios" className="hover:text-pink-500 transition-colors">Tratamientos</a>
              <a href="#turnos" className="hover:text-pink-500 transition-colors">Pedir Turno</a>
              <a href="#opiniones" className="hover:text-pink-500 transition-colors">Opiniones</a>
              <a href="#contacto" className="hover:text-pink-500 transition-colors">Contacto</a>
            </nav>

            {/* Call / Contact details */}
            <div className="hidden lg:flex items-center gap-4 border-l border-pink-100 pl-6">
              <a 
                href={`tel:${BUSINESS_INFO.phone}`}
                className="flex items-center gap-2 text-neutral-700 hover:text-pink-500 transition-colors text-sm font-semibold"
              >
                <div className="w-8 h-8 rounded-full bg-pink-50 flex items-center justify-center text-pink-500">
                  <Phone className="w-4 h-4" />
                </div>
                <span>{BUSINESS_INFO.phoneDisplay}</span>
              </a>
              <a 
                href="#turnos" 
                className="bg-pink-500 text-white px-5 py-2.5 rounded-full text-xs font-semibold hover:bg-pink-600 hover:shadow-md transition-all uppercase tracking-wider"
              >
                Reservar Turno
              </a>
            </div>

            {/* Mobile Menu Buttons */}
            <div className="flex items-center md:hidden gap-3">
              <a 
                href={`https://wa.me/5491121571015?text=${encodeURIComponent(BUSINESS_INFO.whatsappMessageBase)}`}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-full bg-green-50 text-green-600 border border-green-100 hover:bg-green-100 transition-all"
                title="WhatsApp Directo"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.457L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.965C16.528 1.975 14.069.951 11.48.951c-5.44 0-9.866 4.369-9.87 9.799-.001 1.77.475 3.497 1.38 5.02L1.97 21.55l5.882-1.528c1.558.847 3.2 1.292 4.795 1.292z"/>
                </svg>
              </a>
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-lg text-neutral-600 hover:text-pink-500 hover:bg-pink-50 transition-colors"
                aria-label="Toggle Menu"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="md:hidden bg-white border-b border-pink-100 overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-3 font-medium text-base text-neutral-700">
                <a 
                  href="#" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-lg hover:bg-pink-50 hover:text-pink-600 transition-colors"
                >
                  Inicio
                </a>
                <a 
                  href="#servicios" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-lg hover:bg-pink-50 hover:text-pink-600 transition-colors"
                >
                  Tratamientos
                </a>
                <a 
                  href="#turnos" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-lg hover:bg-pink-50 hover:text-pink-600 transition-colors"
                >
                  Pedir Turno
                </a>
                <a 
                  href="#opiniones" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-lg hover:bg-pink-50 hover:text-pink-600 transition-colors"
                >
                  Opiniones
                </a>
                <a 
                  href="#contacto" 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-lg hover:bg-pink-50 hover:text-pink-600 transition-colors"
                >
                  Contacto
                </a>
                
                <div className="pt-4 border-t border-pink-100/60 flex flex-col gap-3 px-3">
                  <div className="text-sm text-neutral-500 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-pink-400" />
                    <span>Llamanos: {BUSINESS_INFO.phoneDisplay}</span>
                  </div>
                  <a 
                    href="#turnos"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="bg-pink-500 text-white text-center py-3 rounded-full text-sm font-semibold hover:bg-pink-600 transition-all"
                  >
                    RESERVAR TURNO ONLINE
                  </a>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* HERO SECTION */}
      <section className="relative bg-gradient-to-b from-pink-50 via-pink-50/20 to-[#FFF5F8] pt-12 pb-20 md:py-24 overflow-hidden">
        
        {/* Background decorative elements */}
        <div className="absolute top-10 left-10 w-64 h-64 bg-pink-200/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-10 w-80 h-80 bg-pink-100/20 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Hero Text */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-pink-100/70 border border-pink-200/50 text-pink-600 font-semibold text-xs uppercase tracking-widest">
                <Heart className="w-3.5 h-3.5 fill-current" /> Espacio de Bienestar Integral
              </div>
              
              <h1 className="font-sans text-4xl sm:text-5xl lg:text-6xl font-light tracking-tight text-neutral-800 leading-[1.15] md:leading-tight">
                Tu belleza natural, <br />
                <span className="text-pink-500 font-semibold italic">realzada profesionalmente.</span>
              </h1>
              
              <p className="text-neutral-500 text-base sm:text-lg max-w-2xl mx-auto lg:mx-0 font-light leading-relaxed">
                Descubrí un santuario de calma diseñado exclusivamente para vos en el corazón de Palermo. 
                Ofrecemos tratamientos faciales avanzados, masajes corporales, manicuría y pestañas con 
                estándares premium para reconectar con tu bienestar.
              </p>

              {/* Trust Indicators */}
              <div className="grid grid-cols-3 gap-3 max-w-md mx-auto lg:mx-0 pt-2 pb-2">
                <div className="glass-panel p-3 rounded-2xl text-center">
                  <div className="text-pink-500 font-sans text-xl sm:text-2xl font-light">12+</div>
                  <div className="text-[10px] sm:text-xs text-neutral-400 uppercase tracking-widest font-semibold">Servicios</div>
                </div>
                <div className="glass-panel p-3 rounded-2xl text-center">
                  <div className="text-pink-500 font-sans text-xl sm:text-2xl font-light">100%</div>
                  <div className="text-[10px] sm:text-xs text-neutral-400 uppercase tracking-widest font-semibold">Seguro</div>
                </div>
                <div className="glass-panel p-3 rounded-2xl text-center">
                  <div className="text-pink-500 font-sans text-xl sm:text-2xl font-light">4.9 ★</div>
                  <div className="text-[10px] sm:text-xs text-neutral-400 uppercase tracking-widest font-semibold">Calificación</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <a 
                  href="#turnos" 
                  className="bg-pink-500 hover:bg-pink-600 text-white text-sm font-semibold px-8 py-4 rounded-full shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2 group"
                >
                  <Calendar className="w-4.5 h-4.5 group-hover:rotate-6 transition-transform" />
                  Reservar Turno Online
                </a>
                <a 
                  href="#servicios" 
                  className="bg-white hover:bg-pink-50 text-neutral-800 border border-pink-200 text-sm font-semibold px-8 py-4 rounded-full hover:shadow-md transition-all flex items-center justify-center gap-2"
                >
                  Ver Menú de Precios
                </a>
              </div>

              {/* Highlight Note */}
              <div className="flex items-center gap-2 justify-center lg:justify-start text-xs text-neutral-500 pt-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Atención con reserva previa • Confirmación rápida por WhatsApp</span>
              </div>
            </div>

            {/* Hero Image / Card */}
            <div className="lg:col-span-5 relative mt-6 lg:mt-0">
              <div className="absolute inset-0 bg-gradient-to-tr from-pink-400 to-amber-200 rounded-3xl opacity-10 blur-xl transform translate-x-3 translate-y-3" />
              <div className="relative glass-panel p-3 rounded-[32px] shadow-lg overflow-hidden group">
                <div className="aspect-[4/3] sm:aspect-square md:aspect-[4/3] lg:aspect-[4/5] rounded-2xl overflow-hidden relative">
                  <img 
                    src={heroImg} 
                    alt="Centro de estética Aura" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/40 via-transparent to-transparent" />
                  
                  {/* Floating badge inside image */}
                  <div className="absolute bottom-4 left-4 right-4 glass-panel p-4 rounded-xl flex items-center justify-between shadow-lg">
                    <div>
                      <div className="text-xs text-pink-500 uppercase font-semibold tracking-widest">¿Por qué elegirnos?</div>
                      <div className="text-sm font-sans font-medium text-neutral-900 mt-0.5">Espacio Rosa & Blanco de Calma</div>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center text-white">
                      <Heart className="w-5 h-5 fill-current text-white" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* HIGHLIGHT VALUES BAR */}
      <section className="bg-white/50 backdrop-blur-md border-y border-pink-100 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-pink-50 flex-shrink-0 flex items-center justify-center text-pink-500 border border-pink-100">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-sans text-lg font-medium text-neutral-900">Profesionales Certificadas</h3>
                <p className="text-sm text-neutral-500 mt-1 font-light">Especialistas matriculadas en constante formación técnica de vanguardia.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-pink-50 flex-shrink-0 flex items-center justify-center text-pink-500 border border-pink-100">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-sans text-lg font-medium text-neutral-900">Materiales & Productos Premium</h3>
                <p className="text-sm text-neutral-500 mt-1 font-light">Utilizamos marcas hipoalergénicas líderes aprobadas para cuidar tu salud.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-pink-50 flex-shrink-0 flex items-center justify-center text-pink-500 border border-pink-100">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-sans text-lg font-medium text-neutral-900">Atención 1 a 1 Exclusiva</h3>
                <p className="text-sm text-neutral-500 mt-1 font-light">Bloques de tiempo amplios sin apuros, diseñados para tu desconexión total.</p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* SERVICES & PRICES SECTION */}
      <section id="servicios" ref={servicesRef} className="py-20 bg-custom-pink relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
            <span className="text-xs uppercase font-bold tracking-widest text-pink-600">Nuestra Carta de Tratamientos</span>
            <h2 className="font-sans text-3xl sm:text-4xl font-light tracking-tight text-neutral-800">Servicios Diseñados para Consentirte</h2>
            <div className="w-16 h-0.5 bg-pink-300 mx-auto mt-2 rounded-full" />
            <p className="text-neutral-500 text-sm sm:text-base mt-2 font-light">
              Explorá nuestra variedad de opciones estéticas con precios transparentes y duraciones exactas. 
              Seleccioná el servicio que deseas para precargar el formulario de turnos de manera directa.
            </p>
          </div>

          {/* Interactive Categories Tabs */}
          <div className="flex flex-wrap justify-center gap-2 mb-10 max-w-4xl mx-auto">
            {CATEGORIES.map(category => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all duration-200 border cursor-pointer ${
                  activeCategory === category.id
                    ? 'bg-pink-500 text-white border-pink-500 shadow-md shadow-pink-100/50'
                    : 'bg-white text-neutral-700 border-pink-100 hover:border-pink-300 hover:bg-pink-50/20'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* Services Grid with Animation */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredServices.map(service => (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  key={service.id}
                  className="glass-panel rounded-3xl p-6 flex flex-col justify-between shadow-xs service-card group"
                >
                  <div>
                    {/* Header Card info */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <span className="inline-block px-3 py-1 rounded-full bg-pink-50 text-[10px] text-pink-600 font-bold uppercase tracking-widest border border-pink-100/50">
                        {service.category}
                      </span>
                      <div className="flex items-center gap-1.5 text-neutral-500 text-xs font-semibold bg-neutral-50 px-2 py-1 rounded-lg">
                        <Clock className="w-3.5 h-3.5 text-pink-400" />
                        <span>{service.duration}</span>
                      </div>
                    </div>

                    <h3 className="font-sans text-lg font-medium text-neutral-900 group-hover:text-pink-500 transition-colors mt-1">
                      {service.name}
                    </h3>

                    <p className="text-sm text-neutral-500 mt-2 line-clamp-3 leading-relaxed font-light">
                      {service.description}
                    </p>
                  </div>

                  {/* Bottom pricing and select CTA */}
                  <div className="mt-6 pt-4 border-t border-pink-100/50 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-neutral-400 block font-semibold leading-tight">Valor</span>
                      <span className="font-sans text-xl font-medium text-neutral-900">${service.price.toLocaleString('es-AR')}</span>
                    </div>

                    <button
                      onClick={() => handleSelectAndScrollToBook(service.id)}
                      className="px-4 py-2 rounded-full bg-pink-50 hover:bg-pink-500 text-pink-600 hover:text-white text-xs font-bold transition-all border border-pink-100 cursor-pointer flex items-center gap-1"
                    >
                      <span>Reservar</span>
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Quick Info Box */}
          <div className="mt-12 glass-panel rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 max-w-4xl mx-auto">
            <div className="flex items-center gap-4 text-center md:text-left">
              <div className="w-12 h-12 rounded-full bg-pink-100 flex items-center justify-center text-pink-500 shrink-0 hidden sm:flex">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-sans text-lg font-medium text-neutral-900">¿Querés un tratamiento a medida?</h4>
                <p className="text-sm text-neutral-500 mt-0.5 font-light">Ofrecemos diagnósticos y asesoramientos personalizados sin costo vía WhatsApp.</p>
              </div>
            </div>
            <a
              href={`https://wa.me/5491121571015?text=${encodeURIComponent('Hola! Me gustaría coordinar un diagnóstico personalizado de piel o pestañas.')}`}
              target="_blank"
              rel="noreferrer"
              className="btn-whatsapp-custom text-white font-semibold text-xs py-3 px-6 rounded-full shadow-md flex items-center gap-2"
            >
              Consultar por WhatsApp
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      </section>

      {/* APPOINTMENT REQUEST FORM & RECENT BOOKINGS */}
      <section id="turnos" className="py-20 bg-custom-pink border-t border-pink-100 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Form Section */}
            <div ref={formRef} className="lg:col-span-7 glass-panel p-6 sm:p-10 rounded-[32px] shadow-sm">
              
              <div className="space-y-3 mb-8">
                <span className="text-xs uppercase font-bold tracking-widest text-pink-600 block">Agenda en unos clics</span>
                <h2 className="font-sans text-2xl sm:text-3xl font-light tracking-tight text-neutral-800">Solicitá tu Turno Online</h2>
                <p className="text-sm text-neutral-500 font-light leading-relaxed">
                  Completá tus datos, seleccioná el tratamiento y elegí el día de tu conveniencia. 
                  Una vez finalizado, podrás enviar la solicitud directamente a nuestro WhatsApp para confirmarlo al instante.
                </p>
              </div>

              <form onSubmit={handleFormSubmit} className="space-y-6">
                
                {/* Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-neutral-600 uppercase tracking-wider block">
                      Nombre Completo <span className="text-pink-500">*</span>
                    </label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ej. María Pérez" 
                      value={formData.clientName}
                      onChange={(e) => setFormData(prev => ({ ...prev, clientName: e.target.value }))}
                      className="w-full px-4 py-3.5 rounded-2xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-transparent text-sm text-neutral-800 placeholder-neutral-400 font-light"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-medium text-neutral-600 uppercase tracking-wider block">
                      Teléfono / WhatsApp <span className="text-pink-500">*</span>
                    </label>
                    <input 
                      type="tel" 
                      required
                      placeholder="Ej. 11 2157-1015" 
                      value={formData.clientPhone}
                      onChange={(e) => setFormData(prev => ({ ...prev, clientPhone: e.target.value }))}
                      className="w-full px-4 py-3.5 rounded-2xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-transparent text-sm text-neutral-800 placeholder-neutral-400 font-light"
                    />
                    <span className="text-[10px] text-neutral-400 block mt-0.5">Ingresá tu número con código de área (sin el 0 ni el 15)</span>
                  </div>
                </div>

                {/* Service Select & Date */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-neutral-600 uppercase tracking-wider block">
                      Tratamiento Deseado <span className="text-pink-500">*</span>
                    </label>
                    <select 
                      value={formData.serviceId}
                      onChange={(e) => setFormData(prev => ({ ...prev, serviceId: e.target.value }))}
                      className="w-full px-4 py-3.5 rounded-2xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-transparent text-sm text-neutral-800 bg-white font-light"
                    >
                      {SERVICES.map(service => (
                        <option key={service.id} value={service.id}>
                          {service.name} (${service.price.toLocaleString('es-AR')})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-medium text-neutral-600 uppercase tracking-wider block">
                      Fecha <span className="text-pink-500">*</span>
                    </label>
                    <div className="relative">
                      <input 
                        type="date" 
                        required
                        min={getTodayDateString()}
                        value={formData.date}
                        onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                        className="w-full px-4 py-3.5 rounded-2xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-transparent text-sm text-neutral-800 placeholder-neutral-400 font-light"
                      />
                    </div>
                  </div>
                </div>

                {/* Time Slot Picker */}
                <div className="space-y-3">
                  <label className="text-xs font-medium text-neutral-600 uppercase tracking-wider block">
                    Horario Preferido <span className="text-pink-500">*</span>
                  </label>
                  
                  <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5">
                    {['09:00', '10:30', '12:00', '13:30', '15:00', '16:30', '18:00'].map(slot => (
                      <button
                        type="button"
                        key={slot}
                        onClick={() => setFormData(prev => ({ ...prev, time: slot }))}
                        className={`py-2 px-1.5 rounded-2xl text-xs font-semibold text-center transition-all border cursor-pointer ${
                          formData.time === slot
                            ? 'bg-pink-500 text-white border-pink-500 shadow-md shadow-pink-100/50'
                            : 'bg-white text-neutral-700 border-pink-100 hover:border-pink-200 hover:bg-pink-50/20'
                        }`}
                      >
                        {slot} hs
                      </button>
                    ))}
                  </div>
                </div>

                {/* Additional Notes */}
                <div className="space-y-2">
                  <label className="text-xs font-medium text-neutral-600 uppercase tracking-wider block">
                    Notas o Consultas Adicionales <span className="text-neutral-400">(Opcional)</span>
                  </label>
                  <textarea 
                    rows={3}
                    placeholder="Ej: Tengo piel sensible / Es para regalo de cumpleaños / Necesito retirar esmalte previo"
                    value={formData.notes}
                    onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                    className="w-full px-4 py-3.5 rounded-2xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-transparent text-sm text-neutral-800 placeholder-neutral-400 font-light"
                  />
                </div>

                {/* Form submit button */}
                <button
                  type="submit"
                  className="w-full bg-pink-500 hover:bg-pink-600 text-white font-bold py-4 rounded-2xl shadow-md hover:-translate-y-0.5 transition-all text-sm uppercase tracking-widest cursor-pointer flex items-center justify-center gap-2"
                >
                  <Calendar className="w-5 h-5" />
                  Solicitar Turno y Confirmar por WhatsApp
                </button>

                <p className="text-[11px] text-neutral-400 text-center">
                  Al hacer clic, se guardará el registro localmente y se generará la confirmación vía WhatsApp para nuestro equipo.
                </p>

              </form>
            </div>

            {/* Sidebar with hours, contact, and recent appointments */}
            <div className="lg:col-span-5 space-y-8">
              
              {/* Box info: Horarios y Contacto */}
              <div className="glass-panel p-6 sm:p-8 rounded-3xl shadow-xs space-y-6">
                <h3 className="font-sans text-xl font-semibold text-neutral-900 border-b border-pink-100/30 pb-3 flex items-center gap-2">
                  <Heart className="w-5 h-5 text-pink-500 fill-current" /> Datos de Contacto
                </h3>
                
                <ul className="space-y-4 text-sm text-neutral-600">
                  <li className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-pink-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold block text-neutral-900">Ubicación</span>
                      <span className="font-light">{BUSINESS_INFO.address}</span>
                    </div>
                  </li>
                  
                  <li className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-pink-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold block text-neutral-900">Teléfono</span>
                      <span className="font-light">{BUSINESS_INFO.phoneDisplay}</span>
                    </div>
                  </li>

                  <li className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-pink-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold block text-neutral-900">Horarios de Atención</span>
                      <p className="text-xs font-light">{BUSINESS_INFO.schedule.weekdays}</p>
                      <p className="text-xs font-light mt-0.5">{BUSINESS_INFO.schedule.saturdays}</p>
                      <p className="text-xs text-pink-600 font-semibold mt-0.5">{BUSINESS_INFO.schedule.sundays}</p>
                    </div>
                  </li>
                </ul>

                <div className="bg-pink-50/50 p-4 rounded-2xl border border-pink-100/30 text-xs flex items-center justify-between">
                  <span className="text-neutral-500">¿Dudas? Chatea con nosotros</span>
                  <a 
                    href={`https://wa.me/5491121571015?text=${encodeURIComponent(BUSINESS_INFO.whatsappMessageBase)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="font-bold text-pink-600 hover:text-pink-700 flex items-center gap-1"
                  >
                    Abrir Chat <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Box Turnos Recientes (Persistent History) */}
              <div className="glass-panel p-6 rounded-3xl shadow-xs">
                <div className="flex items-center justify-between border-b border-pink-100/30 pb-3 mb-4">
                  <h3 className="font-sans text-lg font-semibold text-neutral-900 flex items-center gap-2">
                    <Bookmark className="w-4.5 h-4.5 text-pink-500" /> Tus Turnos Recientes
                  </h3>
                  {appointments.length > 0 && (
                    <span className="px-2 py-0.5 bg-pink-100 text-pink-700 text-[10px] font-bold rounded-full">
                      {appointments.length}
                    </span>
                  )}
                </div>

                {appointments.length === 0 ? (
                  <div className="text-center py-8 text-neutral-400 space-y-2">
                    <Calendar className="w-8 h-8 text-pink-200 mx-auto" />
                    <p className="text-xs font-medium">Aún no solicitaste ningún turno.</p>
                    <p className="text-[10px] text-neutral-400">Los turnos que solicites se guardarán aquí para tu control.</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1">
                    {appointments.map((apt) => (
                      <div 
                        key={apt.id}
                        className="bg-white/85 rounded-2xl p-4 border border-pink-100/40 flex flex-col justify-between hover:border-pink-200/50 transition-colors"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <span className="font-semibold text-xs text-neutral-900 block truncate">
                              {apt.serviceName}
                            </span>
                            <button
                              onClick={() => handleDeleteAppointment(apt.id)}
                              className="text-neutral-400 hover:text-pink-500 p-1 rounded transition-colors cursor-pointer"
                              title="Borrar de mi registro"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="grid grid-cols-2 gap-2 mt-2 text-[11px] text-neutral-500">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3 text-pink-400" />
                              <span>{apt.date}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-pink-400" />
                              <span>{apt.time} hs</span>
                            </div>
                          </div>
                          
                          {apt.notes && (
                            <p className="text-[10px] text-neutral-400 italic mt-2 line-clamp-1">
                              Nota: "{apt.notes}"
                            </p>
                          )}
                        </div>

                        {/* WhatsApp retry CTA */}
                        <div className="mt-3 pt-2.5 border-t border-pink-100/30 flex items-center justify-between">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 text-[9px] font-bold border border-amber-100/50">
                            Pendiente por Chat
                          </span>
                          
                          <a 
                            href={getWhatsAppBookingUrl(apt)}
                            target="_blank"
                            rel="noreferrer"
                            className="btn-whatsapp-custom text-white text-[10px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-xs hover:shadow-sm transition-all"
                          >
                            <span>Enviar WA</span>
                            <Send className="w-2.5 h-2.5" />
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* REVIEWS & TESTIMONIALS SECTION */}
      <section id="opiniones" className="py-20 bg-custom-pink relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
            <span className="text-xs uppercase font-bold tracking-widest text-pink-600">Lo que dicen nuestras clientas</span>
            <h2 className="font-sans text-3xl sm:text-4xl font-light tracking-tight text-neutral-800">Testimonios Reales de Experiencias Aura</h2>
            <div className="w-12 h-0.5 bg-pink-300 mx-auto mt-2 rounded-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {allReviews.map((rev) => (
              <div 
                key={rev.id} 
                className="glass-panel p-6 rounded-3xl shadow-xs flex flex-col justify-between service-card"
              >
                <div>
                  {/* Rating Stars */}
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-4 h-4 ${i < rev.rating ? 'text-amber-400 fill-amber-400' : 'text-neutral-200'}`} 
                      />
                    ))}
                  </div>
                  
                  {/* Review Text */}
                  <p className="text-sm text-neutral-600 italic leading-relaxed font-light">
                    "{rev.text}"
                  </p>
                </div>

                {/* Author Info */}
                <div className="mt-6 pt-4 border-t border-pink-100/30 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-neutral-900 block">{rev.author}</span>
                    <span className="text-[10px] text-neutral-400">{rev.date}</span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-pink-50 flex items-center justify-center text-pink-300">
                    <Heart className="w-4 h-4 fill-current" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Interactive Review Writing Widget */}
          <div className="mt-12 max-w-xl mx-auto">
            {reviewSuccess && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-4 rounded-2xl mb-4 text-center font-semibold">
                ¡Muchas gracias! Tu opinión ha sido publicada y guardada localmente de manera exitosa. 🌸
              </div>
            )}

            {!isAddingReview ? (
              <div className="text-center">
                <button
                  onClick={() => setIsAddingReview(true)}
                  className="bg-white hover:bg-pink-50 text-pink-600 border border-pink-100 font-bold text-xs py-3.5 px-6 rounded-full cursor-pointer transition-all hover:shadow-xs"
                >
                  Dejar mi propia opinión
                </button>
              </div>
            ) : (
              <form 
                ref={reviewFormRef}
                onSubmit={handleReviewSubmit} 
                className="glass-panel rounded-3xl p-6 shadow-sm space-y-4"
              >
                <div className="flex items-center justify-between border-b border-pink-100 pb-2">
                  <h4 className="font-sans text-sm font-medium text-neutral-900">Escribir mi Reseña</h4>
                  <button 
                    type="button" 
                    onClick={() => setIsAddingReview(false)}
                    className="text-neutral-400 hover:text-neutral-600 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Nombre</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Tu nombre" 
                      value={newReview.author}
                      onChange={(e) => setNewReview(prev => ({ ...prev, author: e.target.value }))}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-1 focus:ring-pink-300 text-neutral-800 placeholder-neutral-400 font-light"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Puntaje</label>
                    <select 
                      value={newReview.rating}
                      onChange={(e) => setNewReview(prev => ({ ...prev, rating: Number(e.target.value) }))}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-1 focus:ring-pink-300 text-neutral-800 bg-white font-light"
                    >
                      <option value="5">5 Estrellas (Excelente)</option>
                      <option value="4">4 Estrellas (Muy Bueno)</option>
                      <option value="3">3 Estrellas (Bueno)</option>
                      <option value="2">2 Estrellas (Regular)</option>
                      <option value="1">1 Estrella (Insatisfactorio)</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Comentario</label>
                  <textarea 
                    rows={2.5}
                    required
                    placeholder="Contanos tu experiencia..."
                    value={newReview.text}
                    onChange={(e) => setNewReview(prev => ({ ...prev, text: e.target.value }))}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-pink-50/70 border border-pink-100/50 focus:outline-none focus:ring-1 focus:ring-pink-300 text-neutral-800 placeholder-neutral-400 font-light"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingReview(false)}
                    className="px-3 py-2 text-[11px] rounded-lg border border-neutral-200 text-neutral-500 hover:bg-neutral-50 cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="bg-pink-500 text-white px-4 py-2 text-[11px] font-bold rounded-lg hover:bg-pink-600 transition-colors cursor-pointer"
                  >
                    Publicar Reseña
                  </button>
                </div>
              </form>
            )}
          </div>

        </div>
      </section>

      {/* FAQS SECTION */}
      <section className="py-20 bg-white border-t border-pink-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-12 space-y-3">
            <span className="text-xs uppercase font-bold tracking-widest text-pink-600">Preguntas Frecuentes</span>
            <h2 className="font-sans text-3xl sm:text-4xl font-light tracking-tight text-neutral-800">Resolvé tus Dudas al Instante</h2>
            <div className="w-12 h-0.5 bg-pink-300 mx-auto mt-2 rounded-full" />
          </div>

          <div className="space-y-4">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaqIndexes.includes(idx);
              return (
                <div 
                  key={idx}
                  className="border border-pink-100 rounded-2xl overflow-hidden bg-pink-50/20"
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full px-6 py-4.5 text-left flex items-center justify-between gap-4 font-sans text-sm sm:text-base font-medium text-neutral-900 hover:bg-pink-50/40 transition-colors cursor-pointer"
                  >
                    <span>{faq.question}</span>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-pink-500 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-neutral-400 shrink-0" />
                    )}
                  </button>

                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden bg-white border-t border-pink-100/30"
                      >
                        <div className="p-6 text-xs sm:text-sm text-neutral-500 font-light leading-relaxed">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* FOOTER & MAP / CONTACT SECTION */}
      <footer id="contacto" className="bg-neutral-900 text-neutral-300 pt-16 pb-12 border-t border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 border-b border-neutral-800 pb-12">
            
            {/* Column 1: Brand & Desc */}
            <div className="md:col-span-4 space-y-4 text-center md:text-left">
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <div className="w-9 h-9 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700">
                  <Sparkles className="w-4.5 h-4.5 text-pink-400" />
                </div>
                <div>
                  <span className="font-sans text-lg font-light tracking-tight text-white block">
                    Aura
                  </span>
                  <span className="text-[9px] tracking-widest uppercase text-pink-400 font-semibold block">
                    Estética & Bienestar
                  </span>
                </div>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed max-w-sm mx-auto md:mx-0 font-light">
                Ofrecemos tratamientos de alta gama y atención de excelencia para redefinir el cuidado de tu piel y cuerpo. Disfruta un momento solo para vos.
              </p>
              
              {/* Instagram link */}
              <div className="flex justify-center md:justify-start pt-2">
                <a 
                  href="https://instagram.com" 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex items-center gap-1.5 text-xs font-semibold text-pink-400 hover:text-pink-300 transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                  <span>{BUSINESS_INFO.instagram}</span>
                </a>
              </div>
            </div>

            {/* Column 2: Quick Links */}
            <div className="md:col-span-3 space-y-4 text-center md:text-left">
              <h4 className="font-sans text-sm font-semibold text-white uppercase tracking-wider">Tratamientos</h4>
              <ul className="space-y-2 text-xs text-neutral-400 font-light">
                <li><a href="#servicios" className="hover:text-pink-400 transition-colors">Limpieza Facial Profunda</a></li>
                <li><a href="#servicios" className="hover:text-pink-400 transition-colors">Drenaje Linfático</a></li>
                <li><a href="#servicios" className="hover:text-pink-400 transition-colors">Kapping Gel & Uñas</a></li>
                <li><a href="#servicios" className="hover:text-pink-400 transition-colors">Lifting & Extensión Pestañas</a></li>
              </ul>
            </div>

            {/* Column 3: Schedule & Phone */}
            <div className="md:col-span-5 space-y-4 text-center md:text-left">
              <h4 className="font-sans text-sm font-semibold text-white uppercase tracking-wider">Ubicación & Contacto</h4>
              
              <ul className="space-y-3.5 text-xs text-neutral-400 font-light">
                <li className="flex items-start gap-2.5 justify-center md:justify-start">
                  <MapPin className="w-4 h-4 text-pink-400 shrink-0" />
                  <span>{BUSINESS_INFO.address}</span>
                </li>

                <li className="flex items-start gap-2.5 justify-center md:justify-start">
                  <Phone className="w-4 h-4 text-pink-400 shrink-0" />
                  <a href={`tel:${BUSINESS_INFO.phone}`} className="hover:text-white transition-colors">
                    Tel: {BUSINESS_INFO.phoneDisplay} (Línea Directa)
                  </a>
                </li>

                <li className="flex items-start gap-2.5 justify-center md:justify-start">
                  <Clock className="w-4 h-4 text-pink-400 shrink-0" />
                  <div>
                    <span className="block">{BUSINESS_INFO.schedule.weekdays}</span>
                    <span className="block mt-0.5">{BUSINESS_INFO.schedule.saturdays}</span>
                  </div>
                </li>
              </ul>
            </div>

          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between pt-8 text-[11px] text-neutral-500 gap-4">
            <p>© {new Date().getFullYear()} Aura Estética & Bienestar. Todos los derechos reservados.</p>
            <div className="flex gap-4">
              <span>Palermo, Ciudad Autónoma de Buenos Aires</span>
              <span>•</span>
              <a href="#turnos" className="hover:text-pink-400 transition-colors">Reservar Turno</a>
            </div>
          </div>

        </div>
      </footer>

      {/* FLOAT WHATSAPP BUTTON */}
      <a
        href={`https://wa.me/5491121571015?text=${encodeURIComponent(BUSINESS_INFO.whatsappMessageBase)}`}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 btn-whatsapp-custom rounded-full flex items-center justify-center shadow-2xl hover:scale-105 transition-all text-white animate-bounce pointer-events-auto cursor-pointer"
        style={{ animationDuration: '3s' }}
        title="Consultar por WhatsApp"
      >
        <svg className="w-7 h-7 fill-current text-white" viewBox="0 0 24 24">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.457L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.965C16.528 1.975 14.069.951 11.48.951c-5.44 0-9.866 4.369-9.87 9.799-.001 1.77.475 3.497 1.38 5.02L1.97 21.55l5.882-1.528c1.558.847 3.2 1.292 4.795 1.292z"/>
        </svg>
      </a>

      {/* CONFIRMATION MODAL */}
      <AnimatePresence>
        {activeConfirmationAppointment && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveConfirmationAppointment(null)}
              className="fixed inset-0 bg-neutral-950/60 backdrop-blur-xs transition-opacity"
            />

            {/* Modal Body container */}
            <div className="flex min-h-full items-center justify-center p-4 text-center">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative transform overflow-hidden rounded-[32px] bg-white px-6 pt-8 pb-7 text-left shadow-2xl transition-all w-full max-w-lg border border-pink-100/40"
              >
                {/* Close Button */}
                <button
                  onClick={() => setActiveConfirmationAppointment(null)}
                  className="absolute top-5 right-5 text-neutral-400 hover:text-neutral-600 p-1.5 rounded-full hover:bg-neutral-50 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="space-y-4">
                  {/* Success Icon */}
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-500 border border-emerald-100">
                    <Check className="w-8 h-8" />
                  </div>

                  <div className="text-center space-y-1">
                    <h3 className="font-sans text-2xl font-light tracking-tight text-neutral-800">
                      ¡Solicitud Pre-Registrada!
                    </h3>
                    <p className="text-xs text-neutral-500 font-medium">
                      Tu turno ha sido agendado en tu panel local.
                    </p>
                  </div>

                  {/* Summary card */}
                  <div className="bg-pink-50/30 rounded-2xl p-5 border border-pink-100/30 space-y-3.5 text-xs text-neutral-700">
                    <div className="flex items-center justify-between border-b border-pink-100/30 pb-2">
                      <span className="font-bold text-neutral-500 uppercase tracking-wide">Tratamiento</span>
                      <span className="font-bold text-neutral-900">{activeConfirmationAppointment.serviceName}</span>
                    </div>

                    <div className="flex items-center justify-between border-b border-pink-100/30 pb-2">
                      <span className="font-bold text-neutral-500 uppercase tracking-wide">Cliente</span>
                      <span className="font-semibold text-neutral-900">{activeConfirmationAppointment.clientName}</span>
                    </div>

                    <div className="flex items-center justify-between border-b border-pink-100/30 pb-2">
                      <span className="font-bold text-neutral-500 uppercase tracking-wide">Fecha & Hora</span>
                      <span className="font-semibold text-pink-600">{activeConfirmationAppointment.date} a las {activeConfirmationAppointment.time} hs</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="font-bold text-neutral-500 uppercase tracking-wide">Valor estimado</span>
                      <span className="font-sans font-medium text-sm text-neutral-950">${activeConfirmationAppointment.price.toLocaleString('es-AR')}</span>
                    </div>
                  </div>

                  {/* Next Steps message */}
                  <div className="bg-emerald-50 text-emerald-800 text-[11px] p-3 rounded-xl border border-emerald-100 text-center font-medium leading-relaxed">
                    👉 <strong>ÚLTIMO PASO REQUERIDO:</strong> Para confirmar definitivamente el turno con nuestra agenda física, hace clic abajo y envíanos el mensaje prearmado por WhatsApp.
                  </div>

                  {/* Action confirmation button to open WhatsApp */}
                  <div className="flex flex-col gap-2 pt-2">
                    <a
                      href={getWhatsAppBookingUrl(activeConfirmationAppointment)}
                      target="_blank"
                      rel="noreferrer"
                      onClick={() => setActiveConfirmationAppointment(null)}
                      className="w-full btn-whatsapp-custom text-white font-bold py-3.5 rounded-2xl shadow-md transition-all text-xs uppercase tracking-wider text-center flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.457L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.965C16.528 1.975 14.069.951 11.48.951c-5.44 0-9.866 4.369-9.87 9.799-.001 1.77.475 3.497 1.38 5.02L1.97 21.55l5.882-1.528c1.558.847 3.2 1.292 4.795 1.292z"/>
                      </svg>
                      Enviar Turno por WhatsApp
                    </a>
                    
                    <button
                      type="button"
                      onClick={() => setActiveConfirmationAppointment(null)}
                      className="w-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-bold py-3 rounded-2xl transition-all text-xs uppercase cursor-pointer"
                    >
                      Hacerlo más tarde
                    </button>
                  </div>

                </div>
              </motion.div>
            </div>

          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
