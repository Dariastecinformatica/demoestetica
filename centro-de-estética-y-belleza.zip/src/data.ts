import { Service, Review } from './types';

export const BUSINESS_INFO = {
  name: 'Aura Estética & Bienestar',
  phone: '1121571015',
  phoneDisplay: '11 2157-1015',
  phoneDisplayInt: '+54 9 11 2157-1015',
  instagram: '@aura.esteticabienestar',
  address: 'Av. Santa Fe 3400, Palermo, CABA',
  schedule: {
    weekdays: 'Lunes a Viernes: 09:00 a 20:00 hs',
    saturdays: 'Sábados: 09:00 a 17:00 hs',
    sundays: 'Domingos: Cerrado',
  },
  whatsappMessageBase: '¡Hola Aura! Me contacto desde la web. Me gustaría consultar o pedir información sobre los tratamientos.',
};

export const SERVICES: Service[] = [
  // FACIALES
  {
    id: 'f1',
    name: 'Limpieza Facial Profunda',
    description: 'Exfoliación, extracciones minuciosas, altafrecuencia descongestiva y máscara nutritiva de fango o colágeno para renovar tu piel.',
    price: 18500,
    duration: '60 min',
    category: 'facial',
  },
  {
    id: 'f2',
    name: 'Peeling Químico / Renovación',
    description: 'Tratamiento exfoliante y renovador que combate manchas superficiales, marcas de acné, poros dilatados y líneas de expresión.',
    price: 22000,
    duration: '45 min',
    category: 'facial',
  },
  {
    id: 'f3',
    name: 'Shock de Ácido Hialurónico',
    description: 'Tratamiento de hidratación extrema que rellena líneas finas, restaura la turgencia cutánea y otorga un efecto glow instantáneo.',
    price: 25000,
    duration: '50 min',
    category: 'facial',
  },

  // CORPORALES
  {
    id: 'c1',
    name: 'Masaje Reductor & Modelador',
    description: 'Masajes intensos enfocados en remover adiposidad localizada, drenar y perfilar la silueta mediante técnicas manuales.',
    price: 24000,
    duration: '50 min',
    category: 'corporal',
  },
  {
    id: 'c2',
    name: 'Drenaje Linfático Manual',
    description: 'Técnica suave y descongestiva ideal para piernas cansadas, retención de líquidos, embarazo o recuperación post-quirúrgica.',
    price: 26500,
    duration: '60 min',
    category: 'corporal',
  },
  {
    id: 'c3',
    name: 'Presoterapia Secuencial',
    description: 'Tratamiento mecánico con botas de compresión de aire para activar el retorno venoso, deshinchar y combatir la celulitis.',
    price: 15000,
    duration: '40 min',
    category: 'corporal',
  },

  // MANICURÍA
  {
    id: 'm1',
    name: 'Kapping Gel + Semipermanente',
    description: 'Capa protectora de gel sobre tu uña natural para evitar quiebres y favorecer el crecimiento. Incluye esmaltado y diseño simple.',
    price: 14500,
    duration: '75 min',
    category: 'manicuría',
  },
  {
    id: 'm2',
    name: 'Uñas Esculpidas en Gel',
    description: 'Extensión y esculpido de uñas con gel premium para un largo y forma soñados con un acabado natural, resistente y ultrabrillante.',
    price: 19500,
    duration: '90 min',
    category: 'manicuría',
  },
  {
    id: 'm3',
    name: 'Esmaltado Semipermanente',
    description: 'Limpieza profunda de cutículas, limado anatómico, esmaltado del color que elijas de nuestra paleta y nutrición final.',
    price: 10500,
    duration: '45 min',
    category: 'manicuría',
  },

  // PESTAÑAS Y CEJAS
  {
    id: 'p1',
    name: 'Lifting de Pestañas + Nutrición',
    description: 'Arqueado semipermanente de tus pestañas naturales desde la raíz, haciéndolas parecer más largas y curvas. Incluye tinte y queratina.',
    price: 13500,
    duration: '60 min',
    category: 'pestañas',
  },
  {
    id: 'p2',
    name: 'Extensión de Pestañas Pelo a Pelo',
    description: 'Técnica clásica donde aplicamos una extensión de seda sobre cada una de tus pestañas para lucir una mirada más expresiva y tupida.',
    price: 19000,
    duration: '90 min',
    category: 'pestañas',
  },
  {
    id: 'p3',
    name: 'Perfilado de Cejas + Henna',
    description: 'Diseño personalizado según tu morfología facial con pinza e hilo, sumado a un sombreado natural con henna biodegradable.',
    price: 9500,
    duration: '45 min',
    category: 'pestañas',
  },
];

export const CATEGORIES = [
  { id: 'todos', name: 'Todos los Servicios' },
  { id: 'facial', name: 'Facial' },
  { id: 'corporal', name: 'Corporal' },
  { id: 'manicuría', name: 'Manicuría' },
  { id: 'pestañas', name: 'Pestañas & Cejas' },
];

export const TESTIMONIALS: Review[] = [
  {
    id: 'r1',
    author: 'Camila Rodriguez',
    rating: 5,
    text: 'La atención es maravillosa. Me hice el Shock de Ácido Hialurónico y salí con la piel súper hidratada y un brillo espectacular. Las chicas son muy amables y el espacio transmite muchísima paz.',
    date: 'Hace 1 semana',
  },
  {
    id: 'r2',
    author: 'Sofía Martínez',
    rating: 5,
    text: 'Mi lugar favorito en Palermo. El lifting de pestañas dura un montón y el kapping de uñas me queda impecable siempre. Las recomiendo al 100%. El café de cortesía es un detalle hermoso.',
    date: 'Hace 3 semanas',
  },
  {
    id: 'r3',
    author: 'Valeria Gómez',
    rating: 5,
    text: 'Fui por dolores de retención de líquidos y el drenaje linfático me cambió las piernas. El lugar es sumamente limpio, blanco, rosa y perfumado. Un mimo al alma.',
    date: 'Hace 1 mes',
  },
];

export const FAQS = [
  {
    question: '¿Con cuánta anticipación debo pedir un turno?',
    answer: 'Te recomendamos solicitar tu turno con 48 a 72 horas de anticipación, especialmente para horarios vespertinos o sábados, que suelen tener mayor demanda.',
  },
  {
    question: '¿Cómo funciona la confirmación del turno?',
    answer: 'Al completar el formulario web, tus datos se guardan en el historial y se genera un mensaje de WhatsApp directo. Al hacer clic, nos enviarás el detalle y nosotros te confirmaremos el horario exacto por chat de inmediato.',
  },
  {
    question: '¿Qué formas de pago aceptan?',
    answer: 'Aceptamos pagos en efectivo (con un 10% de descuento de cortesía), transferencia bancaria, Mercado Pago y tarjetas de débito/crédito.',
  },
  {
    question: '¿Tienen estacionamiento o acceso fácil?',
    answer: 'Sí, estamos a solo tres cuadras de la estación de Subte D (Scalabrini Ortiz) y pasan numerosas líneas de colectivo. Hay varios estacionamientos comerciales en la misma cuadra.',
  },
];
