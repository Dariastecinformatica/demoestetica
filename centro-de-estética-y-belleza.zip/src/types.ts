export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string; // e.g., '60 min'
  category: string;
}

export interface Appointment {
  id: string;
  clientName: string;
  clientPhone: string;
  serviceId: string;
  serviceName: string;
  price: number;
  date: string;
  time: string;
  notes?: string;
  createdAt: string;
  status: 'pending_whatsapp' | 'confirmed' | 'cancelled';
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  text: string;
  date: string;
}
